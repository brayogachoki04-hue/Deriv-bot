import {
    analyzeDigitWindow,
    buildProbabilityTable,
    calculateDigitFrequency,
    calculateEvenOddStats,
    calculateOverUnderStats,
    calculateStreaks,
    findHotColdDigits,
    findMissingDigits,
} from '../digitAnalyticsEngine';
import { getLastDigit } from '../getLastDigit';

describe('getLastDigit', () => {
    it('extracts the last decimal digit for the given pip size', () => {
        expect(getLastDigit(1234.56, 2)).toBe(6);
        expect(getLastDigit(1234.5, 1)).toBe(5);
        expect(getLastDigit(1234, 0)).toBe(4);
    });

    it('returns 0 for invalid input instead of throwing', () => {
        expect(getLastDigit(Number.NaN, 2)).toBe(0);
        expect(getLastDigit(1234.56, -1)).toBe(0);
    });
});

describe('calculateDigitFrequency', () => {
    it('counts each digit and computes percentage + deviation from uniform 10%', () => {
        const digits = [0, 0, 1, 2, 3, 4, 5, 6, 7, 8]; // 10 digits, digit 0 appears twice
        const frequency = calculateDigitFrequency(digits);

        expect(frequency).toHaveLength(10);
        const digitZero = frequency.find(f => f.digit === 0)!;
        expect(digitZero.count).toBe(2);
        expect(digitZero.percentage).toBe(20);
        expect(digitZero.deviation).toBe(10);

        const digitNine = frequency.find(f => f.digit === 9)!;
        expect(digitNine.count).toBe(0);
        expect(digitNine.percentage).toBe(0);
    });

    it('handles an empty array without dividing by zero', () => {
        const frequency = calculateDigitFrequency([]);
        expect(frequency.every(f => f.count === 0 && f.percentage === 0)).toBe(true);
    });
});

describe('calculateEvenOddStats', () => {
    it('splits digits into even/odd counts and percentages', () => {
        const stats = calculateEvenOddStats([0, 1, 2, 3, 4, 5]); // 3 even, 3 odd
        expect(stats.even_count).toBe(3);
        expect(stats.odd_count).toBe(3);
        expect(stats.even_percentage).toBe(50);
        expect(stats.odd_percentage).toBe(50);
    });
});

describe('calculateOverUnderStats', () => {
    it('splits digits at the given threshold (default 5)', () => {
        const stats = calculateOverUnderStats([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
        expect(stats.under_count).toBe(5); // 0-4
        expect(stats.over_count).toBe(5); // 5-9
    });
});

describe('calculateStreaks', () => {
    it('finds the current streak, longest streak, and average length', () => {
        // even, even, odd, odd, odd, even -> streak lengths: 2, 3, 1
        const digits = [2, 4, 1, 3, 5, 6];
        const streaks = calculateStreaks(digits, d => (d % 2 === 0 ? 'even' : 'odd'));

        expect(streaks.longest_streak?.length).toBe(3);
        expect(streaks.longest_streak?.type).toBe('odd');
        expect(streaks.current_streak?.type).toBe('even');
        expect(streaks.current_streak?.length).toBe(1);
        expect(streaks.average_streak_length).toBeCloseTo((2 + 3 + 1) / 3, 5);
    });

    it('returns nulls for an empty digit sequence', () => {
        const streaks = calculateStreaks([], d => String(d));
        expect(streaks.current_streak).toBeNull();
        expect(streaks.longest_streak).toBeNull();
        expect(streaks.average_streak_length).toBe(0);
    });

    it('treats a single unbroken run as both the current and longest streak', () => {
        const streaks = calculateStreaks([2, 2, 2], d => String(d));
        expect(streaks.current_streak?.length).toBe(3);
        expect(streaks.longest_streak?.length).toBe(3);
    });
});

describe('findMissingDigits', () => {
    it('returns digits that never occurred in the sample', () => {
        const missing = findMissingDigits([0, 1, 2, 3, 4, 5, 6, 7]);
        expect(missing.sort()).toEqual([8, 9]);
    });

    it('returns an empty array when every digit occurred', () => {
        expect(findMissingDigits([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])).toEqual([]);
    });
});

describe('findHotColdDigits', () => {
    it('identifies the most and least frequent digits', () => {
        const frequency = calculateDigitFrequency([1, 1, 1, 2, 3]);
        const { hot, cold } = findHotColdDigits(frequency);
        expect(hot).toEqual([1]);
        // multiple digits tie for 0 occurrences
        expect(cold).toContain(0);
        expect(cold).toContain(9);
    });
});

describe('buildProbabilityTable', () => {
    it('computes empirical probability as count / sample size', () => {
        const digits = [1, 1, 2, 2, 2, 3];
        const frequency = calculateDigitFrequency(digits);
        const table = buildProbabilityTable(frequency, digits.length);
        expect(table[2]).toBeCloseTo(3 / 6, 4);
        expect(table[1]).toBeCloseTo(2 / 6, 4);
    });
});

describe('analyzeDigitWindow', () => {
    it('assembles a complete window stats bundle', () => {
        const digits = [1, 3, 5, 7, 9, 1, 3, 5, 7, 9];
        const stats = analyzeDigitWindow(digits, 10);

        expect(stats.window_size).toBe(10);
        expect(stats.sample_size).toBe(10);
        expect(stats.even_odd.odd_count).toBe(10);
        expect(stats.even_odd.even_count).toBe(0);
        expect(stats.missing_digits.sort()).toEqual([0, 2, 4, 6, 8]);
        expect(stats.hot_digits.sort()).toEqual([1, 3, 5, 7, 9]);
    });
});
