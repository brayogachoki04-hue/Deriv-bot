/**
 * Digit Analytics Engine — types
 *
 * Statistical analysis of Deriv digit contracts (Matches/Differs, Even/Odd,
 * Over/Under). All values here are descriptive statistics computed from
 * historical ticks. Nothing in this module predicts future outcomes.
 */

export const DIGIT_WINDOW_SIZES = [50, 100, 250, 500, 1000] as const;

export type TDigitWindowSize = (typeof DIGIT_WINDOW_SIZES)[number];

/** A single tick reduced to the digit-analytics-relevant fields. */
export type TDigitTick = {
    /** Epoch (seconds) reported by the API. */
    epoch: number;
    /** Raw quote price as reported by the API. */
    quote: number;
    /** Last significant decimal digit (0-9) of the quote, per the symbol's pip size. */
    digit: number;
};

/** Frequency count + percentage for a single digit (0-9). */
export type TDigitFrequency = {
    digit: number;
    count: number;
    /** Percentage of the window, 0-100, one decimal place. */
    percentage: number;
    /** percentage - 10, i.e. deviation from the theoretical uniform 10%. */
    deviation: number;
};

export type TEvenOddStats = {
    even_count: number;
    odd_count: number;
    even_percentage: number;
    odd_percentage: number;
};

export type TOverUnderStats = {
    /** Digits 5-9 */
    over_count: number;
    /** Digits 0-4 */
    under_count: number;
    over_percentage: number;
    under_percentage: number;
};

export type TStreakInfo = {
    /** The digit or category the streak is made of, e.g. 'even', 'odd', or a digit 0-9. */
    type: string;
    length: number;
    /** Index range within the analyzed window, most recent tick last. */
    start_index: number;
    end_index: number;
};

export type TStreakStats = {
    /** The current unbroken streak ending at the most recent tick, if any. */
    current_streak: TStreakInfo | null;
    /** The longest streak found anywhere in the window. */
    longest_streak: TStreakInfo | null;
    /** Mean streak length across all streaks found in the window. */
    average_streak_length: number;
};

export type TDigitWindowStats = {
    window_size: number;
    /** Number of ticks actually available (may be < window_size early on). */
    sample_size: number;
    frequency: TDigitFrequency[];
    even_odd: TEvenOddStats;
    over_under: TOverUnderStats;
    digit_streaks: TStreakStats;
    even_odd_streaks: TStreakStats;
    /** Digits with zero occurrences in the window. */
    missing_digits: number[];
    /** Digit(s) with the highest / lowest frequency. */
    hot_digits: number[];
    cold_digits: number[];
    /** Empirical probability (0-1) of each digit occurring next, i.e. count / sample_size. */
    probability_table: Record<number, number>;
};

/** Full multi-window analytics snapshot, one entry per configured window size. */
export type TDigitAnalyticsSnapshot = Record<TDigitWindowSize, TDigitWindowStats>;
