import {
    DIGIT_WINDOW_SIZES,
    TDigitAnalyticsSnapshot,
    TDigitFrequency,
    TDigitWindowSize,
    TDigitWindowStats,
    TEvenOddStats,
    TOverUnderStats,
    TStreakInfo,
    TStreakStats,
} from './types';

/**
 * Digit Analytics Engine
 *
 * Pure, side-effect-free statistics functions over an array of last-digits
 * (0-9), most recent digit last. All functions are descriptive statistics
 * only — they characterize what already happened, never what will happen
 * next. Digit outcomes on Deriv's synthetic/volatility indices are
 * independently generated; past frequency has no bearing on future draws.
 */

const round1 = (value: number): number => Math.round(value * 10) / 10;

export const calculateDigitFrequency = (digits: number[]): TDigitFrequency[] => {
    const counts = new Array(10).fill(0);
    digits.forEach(d => {
        if (d >= 0 && d <= 9) counts[d] += 1;
    });

    const total = digits.length || 1;

    return counts.map((count, digit) => {
        const percentage = round1((count / total) * 100);
        return {
            digit,
            count,
            percentage,
            deviation: round1(percentage - 10),
        };
    });
};

export const calculateEvenOddStats = (digits: number[]): TEvenOddStats => {
    const total = digits.length || 1;
    const even_count = digits.filter(d => d % 2 === 0).length;
    const odd_count = digits.length - even_count;

    return {
        even_count,
        odd_count,
        even_percentage: round1((even_count / total) * 100),
        odd_percentage: round1((odd_count / total) * 100),
    };
};

export const calculateOverUnderStats = (digits: number[], threshold = 5): TOverUnderStats => {
    const total = digits.length || 1;
    const over_count = digits.filter(d => d >= threshold).length;
    const under_count = digits.length - over_count;

    return {
        over_count,
        under_count,
        over_percentage: round1((over_count / total) * 100),
        under_percentage: round1((under_count / total) * 100),
    };
};

/**
 * Generic streak calculator. `classify` maps a digit to the category used to
 * determine whether consecutive ticks belong to the same streak (e.g. the
 * digit itself for digit-streaks, or 'even'/'odd' for parity-streaks).
 */
export const calculateStreaks = (digits: number[], classify: (digit: number) => string): TStreakStats => {
    if (digits.length === 0) {
        return { current_streak: null, longest_streak: null, average_streak_length: 0 };
    }

    const streaks: TStreakInfo[] = [];
    let start_index = 0;

    for (let i = 1; i <= digits.length; i += 1) {
        const prev_type = classify(digits[i - 1]);
        const current_type = i < digits.length ? classify(digits[i]) : null;

        if (current_type !== prev_type) {
            streaks.push({
                type: prev_type,
                length: i - start_index,
                start_index,
                end_index: i - 1,
            });
            start_index = i;
        }
    }

    const longest_streak = streaks.reduce<TStreakInfo | null>(
        (longest, streak) => (!longest || streak.length > longest.length ? streak : longest),
        null
    );

    const last_streak = streaks[streaks.length - 1] ?? null;
    const current_streak = last_streak && last_streak.end_index === digits.length - 1 ? last_streak : null;

    const average_streak_length =
        streaks.length > 0 ? round1(streaks.reduce((sum, s) => sum + s.length, 0) / streaks.length) : 0;

    return { current_streak, longest_streak, average_streak_length };
};

export const findMissingDigits = (digits: number[]): number[] => {
    const seen = new Set(digits);
    return Array.from({ length: 10 }, (_, i) => i).filter(digit => !seen.has(digit));
};

export const findHotColdDigits = (frequency: TDigitFrequency[]): { hot: number[]; cold: number[] } => {
    if (frequency.length === 0) return { hot: [], cold: [] };

    const max_count = Math.max(...frequency.map(f => f.count));
    const min_count = Math.min(...frequency.map(f => f.count));

    return {
        hot: frequency.filter(f => f.count === max_count).map(f => f.digit),
        cold: frequency.filter(f => f.count === min_count).map(f => f.digit),
    };
};

export const buildProbabilityTable = (frequency: TDigitFrequency[], sample_size: number): Record<number, number> => {
    const table: Record<number, number> = {};
    frequency.forEach(f => {
        table[f.digit] = sample_size > 0 ? Number((f.count / sample_size).toFixed(4)) : 0;
    });
    return table;
};

/** Computes the full stats bundle for a single window of digits. */
export const analyzeDigitWindow = (digits: number[], window_size: number): TDigitWindowStats => {
    const frequency = calculateDigitFrequency(digits);
    const { hot, cold } = findHotColdDigits(frequency);

    return {
        window_size,
        sample_size: digits.length,
        frequency,
        even_odd: calculateEvenOddStats(digits),
        over_under: calculateOverUnderStats(digits),
        digit_streaks: calculateStreaks(digits, d => String(d)),
        even_odd_streaks: calculateStreaks(digits, d => (d % 2 === 0 ? 'even' : 'odd')),
        missing_digits: findMissingDigits(digits),
        hot_digits: hot,
        cold_digits: cold,
        probability_table: buildProbabilityTable(frequency, digits.length),
    };
};

/**
 * Computes analytics for every configured window size (50/100/250/500/1000)
 * from a single rolling digit buffer. `all_digits` should be ordered oldest
 * to newest; each window takes the most recent N digits.
 */
export const analyzeAllWindows = (all_digits: number[]): TDigitAnalyticsSnapshot => {
    const snapshot = {} as TDigitAnalyticsSnapshot;

    DIGIT_WINDOW_SIZES.forEach((size: TDigitWindowSize) => {
        const windowed = all_digits.slice(-size);
        snapshot[size] = analyzeDigitWindow(windowed, size);
    });

    return snapshot;
};
