/**
 * Extracts the last significant decimal digit of a Deriv quote, respecting
 * the symbol's pip size (decimal precision). This mirrors how Deriv's own
 * digit contracts (Matches/Differs, Even/Odd, Over/Under) determine the
 * "last digit" for settlement.
 *
 * @param quote - The raw price, e.g. 1234.56
 * @param pip_size - Number of decimal places for the symbol, e.g. 2
 */
export const getLastDigit = (quote: number, pip_size: number): number => {
    if (!Number.isFinite(quote) || !Number.isFinite(pip_size) || pip_size < 0) return 0;

    const fixed = quote.toFixed(pip_size);
    const last_char = fixed.charAt(fixed.length - 1);
    const digit = Number(last_char);

    return Number.isNaN(digit) ? 0 : digit;
};
