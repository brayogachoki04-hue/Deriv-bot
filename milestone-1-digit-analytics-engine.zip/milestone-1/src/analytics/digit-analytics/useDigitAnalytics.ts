import { useMemo } from 'react';
import { analyzeAllWindows } from './digitAnalyticsEngine';
import { useDigitTickStream } from './useDigitTickStream';
import { TDigitAnalyticsSnapshot, TDigitWindowSize } from './types';

export type TUseDigitAnalyticsResult = {
    snapshot: TDigitAnalyticsSnapshot | null;
    digits: number[];
    is_subscribed: boolean;
    error: string | null;
};

/**
 * Top-level hook for the Digit Analytics Engine. Subscribes to live ticks
 * for `symbol` and returns statistics for every configured window size
 * (50/100/250/500/1000), recomputed only when the underlying digit buffer
 * actually changes.
 */
export const useDigitAnalytics = (symbol: string | null): TUseDigitAnalyticsResult => {
    const { digits, is_subscribed, error } = useDigitTickStream(symbol);

    // Recompute only when the digit sequence changes; digits.length changes
    // on every tick, which is exactly when a recompute is needed.
    const snapshot = useMemo(() => {
        if (digits.length === 0) return null;
        return analyzeAllWindows(digits);
    }, [digits]);

    return { snapshot, digits, is_subscribed, error };
};

/** Convenience hook for a single window when a component only needs one size. */
export const useDigitWindowStats = (symbol: string | null, window_size: TDigitWindowSize) => {
    const { snapshot, is_subscribed, error } = useDigitAnalytics(symbol);
    return {
        stats: snapshot ? snapshot[window_size] : null,
        is_subscribed,
        error,
    };
};
