import { useCallback, useEffect, useRef, useState } from 'react';
import { api_base } from '@/external/bot-skeleton/services/api/api-base';
import { getLastDigit } from './getLastDigit';
import { TDigitTick } from './types';

/** Largest analytics window (see DIGIT_WINDOW_SIZES) — the buffer never needs to hold more than this. */
const MAX_BUFFER_SIZE = 1000;

type TTickMessage = {
    msg_type?: string;
    tick?: {
        epoch: number;
        quote: number;
        pip_size: number;
        symbol: string;
    };
    history?: {
        prices: number[];
        times: number[];
    };
    pip_size?: number;
    echo_req?: { ticks_history?: string };
    error?: { message: string };
    subscription?: { id: string };
};

export type TUseDigitTickStreamResult = {
    ticks: TDigitTick[];
    digits: number[];
    is_subscribed: boolean;
    error: string | null;
};

/**
 * Subscribes to the live tick stream for `symbol` via the shared api_base
 * connection and maintains a rolling buffer (oldest → newest) of up to
 * MAX_BUFFER_SIZE ticks, each reduced to its last significant digit.
 *
 * Reuses the same authenticated/anonymous websocket connection the rest of
 * the app already uses (api_base) — it does not open a second connection.
 */
export const useDigitTickStream = (symbol: string | null): TUseDigitTickStreamResult => {
    const [ticks, setTicks] = useState<TDigitTick[]>([]);
    const [is_subscribed, setIsSubscribed] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const buffer_ref = useRef<TDigitTick[]>([]);
    const subscription_id_ref = useRef<string | null>(null);

    const pushTick = useCallback((tick: TDigitTick) => {
        const next = [...buffer_ref.current, tick].slice(-MAX_BUFFER_SIZE);
        buffer_ref.current = next;
        setTicks(next);
    }, []);

    useEffect(() => {
        if (!symbol || !api_base?.api) return undefined;

        setError(null);
        setIsSubscribed(false);
        buffer_ref.current = [];
        setTicks([]);

        const handleMessage = (raw: unknown) => {
            const message = raw as TTickMessage;

            if (message.error) {
                setError(message.error.message);
                return;
            }

            // Track this specific subscription's id so cleanup only forgets
            // *our* subscription, never other tick/chart subscriptions in the app.
            if (message.subscription?.id) {
                subscription_id_ref.current = message.subscription.id;
            }

            // Initial ticks_history payload (seed the buffer with recent history).
            if (message.msg_type === 'history' && message.echo_req?.ticks_history === symbol && message.history) {
                const { prices, times } = message.history;
                const pip_size = message.pip_size ?? 0;

                const seeded: TDigitTick[] = prices.map((price, i) => ({
                    epoch: times[i],
                    quote: price,
                    digit: getLastDigit(price, pip_size),
                }));

                buffer_ref.current = seeded.slice(-MAX_BUFFER_SIZE);
                setTicks(buffer_ref.current);
                setIsSubscribed(true);
                return;
            }

            // Live tick updates.
            if (message.msg_type === 'tick' && message.tick?.symbol === symbol) {
                const { quote, epoch, pip_size } = message.tick;
                pushTick({ epoch, quote, digit: getLastDigit(quote, pip_size) });
                setIsSubscribed(true);
            }
        };

        const subscription = api_base.api.onMessage().subscribe(({ data }: { data: unknown }) => {
            handleMessage(data);
        });

        api_base.api.send({
            ticks_history: symbol,
            adjust_start_time: 1,
            count: MAX_BUFFER_SIZE,
            end: 'latest',
            style: 'ticks',
            subscribe: 1,
        });

        return () => {
            subscription?.unsubscribe?.();
            // Forget only this hook's own subscription id (never forget_all,
            // which would tear down chart/bot-engine tick streams too).
            if (subscription_id_ref.current) {
                api_base.api?.send({ forget: subscription_id_ref.current });
                subscription_id_ref.current = null;
            }
        };
    }, [symbol, pushTick]);

    return {
        ticks,
        digits: ticks.map((t: TDigitTick) => t.digit),
        is_subscribed,
        error,
    };
};
